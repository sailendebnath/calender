import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';
import { Appointment } from '../models/appointment.model';
import { v4 as uuidv4 } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private appointments: Appointment[] = [
    {
      id: uuidv4(),
      title: 'Meeting with John',
      description: 'Discuss project updates',
      date: new Date().toJSON().slice(0, 10),
      startTime: '10:00',
      endTime: '11:30'
    }
    // Add more initial appointments if needed
  ];

  getAppointments(): Observable<Appointment[]> {
    return of(this.appointments);
  }

  addAppointment(appointment: Appointment): Observable<Appointment> {
    appointment.id = uuidv4();
    this.appointments.push(appointment);
    return of(appointment);
  }

  editAppointment(appointment: Appointment): Observable<Appointment> {
    const index = this.appointments.findIndex(a => a.id === appointment.id);
    if (index !== -1) {
      this.appointments[index] = appointment;
    }
    return of(appointment);
  }

  deleteAppointment(appointmentId: string): Observable<string> {
    this.appointments = this.appointments.filter(a => a.id !== appointmentId);
    return of(appointmentId);
  }
}
