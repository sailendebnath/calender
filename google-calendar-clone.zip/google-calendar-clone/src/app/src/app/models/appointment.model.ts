export interface Appointment {
    id?: string; // Optional for new appointments, will be generated later
  title: string;
  description?: string;
  date: any; // In 'YYYY-MM-DD' format
  startTime: string; // In 'HH:MM' format
  endTime?: string; // In 'HH:MM' format
  }
  