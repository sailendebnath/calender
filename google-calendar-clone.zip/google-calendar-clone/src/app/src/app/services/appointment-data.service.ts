// appointment-data.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Appointment } from '../models/appointment.model'; // Adjust path as needed

@Injectable({
  providedIn: 'root'
})
export class AppointmentDataService {
  private appointmentSubject = new BehaviorSubject<Appointment | null>(null);
  appointment$ = this.appointmentSubject.asObservable();

  setAppointment(appointment: Appointment | null): void {
    this.appointmentSubject.next(appointment);
  }
}
