import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map, mergeMap } from 'rxjs/operators';
import { AppointmentService } from '../../services/appointment.service';
import * as AppointmentActions from './appointment.actions';

@Injectable()
export class AppointmentEffects {
  loadAppointments$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AppointmentActions.loadAppointments),
      mergeMap(() =>
        this.appointmentService.getAppointments().pipe(
          map(appointments =>
            AppointmentActions.loadAppointmentsSuccess({ appointments })
          )
        )
      )
    )
  );

  constructor(
    private actions$: Actions,
    private appointmentService: AppointmentService
  ) {}
}
