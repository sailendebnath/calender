import { createFeatureSelector, createReducer, on } from '@ngrx/store';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import { v4 as uuidv4 } from 'uuid'; // Import UUID for generating unique IDs
import { Appointment } from '../../models/appointment.model';
import {
  loadAppointmentsSuccess,
  addAppointment,
  editAppointment,
  deleteAppointment
} from './appointment.actions';

// Define the AppointmentState interface, extending EntityState
export interface AppointmentState extends EntityState<Appointment> {}

// Create an adapter for Appointment entities
export const adapter: EntityAdapter<Appointment> = createEntityAdapter<Appointment>();

// Define the initial state using the adapter's getInitialState method
export const initialState: AppointmentState = adapter.getInitialState();

// Create the appointmentReducer with action handlers
export const appointmentReducer = createReducer(
  initialState,
  // Handle loading appointments successfully
  on(loadAppointmentsSuccess, (state, { appointments }) =>
    adapter.setAll(appointments, state)
  ),
  // Handle adding a new appointment, ensuring it has a unique ID
  on(addAppointment, (state, { appointment }) =>
    adapter.addOne({ ...appointment, id: appointment.id ?? uuidv4() }, state)
  ),
  // Handle editing an existing appointment, ensuring the ID is defined
  on(editAppointment, (state, { appointment }) => {
    if (appointment.id) {
      return adapter.updateOne({ id: appointment.id, changes: appointment }, state);
    }
    return state; // If no ID is present, return the current state
  }),
  // Handle deleting an appointment by ID
  on(deleteAppointment, (state, { appointmentId }) =>
    adapter.removeOne(appointmentId, state)
  )
);

// Create a feature selector for the appointments state
export const selectAppointmentState = createFeatureSelector<AppointmentState>('appointments');

// Use the adapter's getSelectors method to create selectors for the appointment state
export const { selectAll, selectEntities, selectIds, selectTotal } = adapter.getSelectors(selectAppointmentState);
