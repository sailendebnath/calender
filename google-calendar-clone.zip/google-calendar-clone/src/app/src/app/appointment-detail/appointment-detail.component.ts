import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Appointment } from '../models/appointment.model';
import { AppointmentService } from '../services/appointment.service';

@Component({
  selector: 'app-appointment-detail',
  templateUrl: './appointment-detail.component.html',
})
export class AppointmentDetailComponent {
  appointment: Appointment;

  constructor(
    public dialogRef: MatDialogRef<AppointmentDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { appointment: Appointment },
    private appointmentService: AppointmentService
  ) {
    this.appointment = { ...data.appointment };
  }

  onSave(): void {
    this.appointmentService.updateAppointment(this.appointment); // Update the service with the new appointment data
    this.dialogRef.close(); // Close the dialog
  }

  onCancel(): void {
    this.dialogRef.close(); // Just close the dialog without updating
  }
}
