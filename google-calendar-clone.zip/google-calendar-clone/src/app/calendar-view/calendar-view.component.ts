import { ChangeDetectorRef, Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Observable, Subject } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';
import { AppointmentDetailComponent } from '../appointment-detail/appointment-detail.component';
import { Appointment } from '../models/appointment.model';
import * as AppointmentActions from '../store/appointment/appointment.actions';
import { AppointmentState, selectAll } from '../store/appointment/appointment.reducer';
import { formatDate } from '@angular/common';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-calendar-view',
  templateUrl: './calendar-view.component.html',
  styleUrls: ['./calendar-view.component.scss']
})
export class CalendarViewComponent implements OnInit, OnDestroy {
  selectedDate: Date = new Date();
  weekDays: Date[] = [];
  timeSlots: string[] = this.generateTimeSlots();
  appointments$: Observable<Appointment[]>;
  weekAppointments: { date: Date; appointments: Appointment[] }[] = [];
  hoveredAppointment: Appointment | null = null;
  private unsubscribe$ = new Subject<void>();

  constructor(
    private dialog: MatDialog,
    private store: Store<{ appointments: AppointmentState }>,
    private cdr: ChangeDetectorRef
  ) {
    this.appointments$ = this.store.select(selectAll);
  }

  ngOnInit() {
    this.loadAppointments();
    this.updateWeekDays();
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  generateTimeSlots(): string[] {
    const timeSlots: string[] = [];
    for (let hour = 0; hour < 24; hour++) {
      for (let minutes = 0; minutes < 60; minutes += 15) {
        const hourString = hour < 10 ? '0' + hour : hour.toString();
        const minuteString = minutes === 0 ? '00' : minutes.toString();
        timeSlots.push(`${hourString}:${minuteString}`);
      }
    }
    return timeSlots;
  }

  loadAppointments() {
    this.store.dispatch(AppointmentActions.loadAppointments());
    this.appointments$.pipe(takeUntil(this.unsubscribe$)).subscribe(() => {
      this.updateWeekDays();
    });
  }

  showAppointmentDetails(appointment: Appointment) {
    this.hoveredAppointment = appointment;
  }

  hideAppointmentDetails() {
    this.hoveredAppointment = null;
  }

  addAppointment(): void {
    this.openAppointmentDialog({} as Appointment);
  }

  addAppointmentForDate(selectedDate: Date): void {
    this.openAppointmentDialog({
      date: selectedDate,
      startTime: '00:00',
      endTime: '01:00',
      title: '',
      description: ''
    });
  }

  addAppointmentForTimeSlot(selectedDate: Date, selectedTime: string): void {
    this.openAppointmentDialog({
      date: selectedDate,
      startTime: selectedTime,
      endTime: this.calculateEndTime(selectedTime),
      title: '',
      description: ''
    });
  }

  editAppointment(appointment: Appointment): void {
    const clonedAppointment = { ...appointment }; // Clone the object
    clonedAppointment.date = new Date(appointment.date); // Ensure date is in correct format
    this.openAppointmentDialog(clonedAppointment);
  }

  openAppointmentDialog(appointment: Appointment): void {
     const dialogRef = this.dialog.open(AppointmentDetailComponent, {
      data: { appointment: { ...appointment } } ,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog result received in component:', result); // Ensure this logs the result correctly

      if (result) {
        Object.assign(appointment, result);
      console.log('Appointment updated:', appointment);
        const updatedAppointment: Appointment = {
          ...appointment,
          title: result.title,
          description: result.description,
          date: this.formatDate(result.date),
          startTime: result.startTime,
          endTime: result.endTime
        };

        console.log('Updated appointment:', updatedAppointment); // Ensure this is the updated data

        const action = appointment.id
          ? AppointmentActions.editAppointment({ appointment: updatedAppointment })
          : AppointmentActions.addAppointment({ appointment: updatedAppointment });

        console.log('Dispatching action:', action); // Ensure this action is as expected

        this.store.dispatch(action);
        this.refreshCalendarView();
      } else {
        console.log('Dialog closed without returning data.');
      }
    });
  }

  updateWeekDays() {
    const startOfWeek = this.getStartOfWeek(this.selectedDate);
    this.weekDays = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);
      return date;
    });
    
    this.appointments$.pipe(takeUntil(this.unsubscribe$)).subscribe(appointments => {
      this.weekAppointments = this.weekDays.map(day => ({
        date: day, // Ensure this is a Date object
        appointments: appointments.filter(app => app.date === this.formatDate(day))
      }));
      this.cdr.detectChanges(); // Ensure view updates
    });
  }

  refreshCalendarView() {
    this.cdr.detectChanges();
    this.updateWeekDays();
  }

  getStartOfWeek(date: Date): Date {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    const startOfWeek = new Date(date);
    startOfWeek.setDate(diff);
    return startOfWeek;
  }

  goToPreviousWeek() {
    this.selectedDate.setDate(this.selectedDate.getDate() - 7);
    this.updateWeekDays();
  }

  goToNextWeek() {
    this.selectedDate.setDate(this.selectedDate.getDate() + 7);
    this.updateWeekDays();
  }

  getWeekRange(): string {
    if (!this.weekDays || this.weekDays.length === 0) {
      return 'No dates available';
    }
    const start = this.weekDays[0];
    const end = this.weekDays[this.weekDays.length - 1];
    return `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`;
  }

  getAppointmentsForSlot(day: Date, slot: string): Observable<Appointment[]> {
    return this.appointments$.pipe(
      map(appointments =>
        appointments.filter(app =>
          app.date === this.formatDate(day) &&
          app.startTime === slot // Only display if the slot matches the startTime
        )
      )
    );
  }

  openAppointmentDetail(appointment: Appointment) {
    this.dialog.open(AppointmentDetailComponent, {
      data: { appointment }
    });
  }

  private calculateEndTime(startTime: string): string {
    const [hours, minutes] = startTime.split(':').map(Number);
    const endTime = new Date();
    endTime.setHours(hours, minutes + 15); // Adjust for 15-minute increments
    return this.formatTime(endTime);
  }

  private formatDate(date: Date | string): string {
    return formatDate(date, 'yyyy-MM-dd', 'en-US');
  }

  private formatTime(date: Date): string {
    return date.toTimeString().slice(0, 5); // Returns time in HH:mm format
  }

  private generateUniqueId(): string {
    return uuidv4();
  }

  calculateAppointmentStyle(appointment: Appointment): { [key: string]: string } {
    const slotHeight = 45.50; // Adjust according to your slot height
    const startMinutes = this.timeToMinutes(appointment.startTime || '00:00');
    const endMinutes = this.timeToMinutes(appointment.endTime || '00:00');
    const top = (startMinutes / 60) * slotHeight;
    const height = ((endMinutes - startMinutes) / 60) * slotHeight;
    return {
      top: `${top}px`,
      height: `${height}px`,
      left: '0px', // Adjust if you have a time column width to account for
      width: '100%' // Adjust as needed
    };
  }

  timeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }

  deleteAppointment(appointmentId: string): void {
    if (confirm('Are you sure you want to delete this appointment?')) {
      this.store.dispatch(AppointmentActions.deleteAppointment({ appointmentId }));
    }
  }
}
