import { createAction, props } from '@ngrx/store';
import { Appointment } from '../../models/appointment.model';

export const loadAppointments = createAction('[Appointment] Load Appointments');

export const loadAppointmentsSuccess = createAction(
  '[Appointment] Load Appointments Success',
  props<{ appointments: Appointment[] }>()
);

export const addAppointment = createAction(
  '[Appointment] Add Appointment',
  props<{ appointment: Appointment }>()
);

export const editAppointment = createAction(
  '[Appointment] Edit Appointment',
  props<{ appointment: Appointment }>()
);

export const deleteAppointment = createAction(
  '[Appointment] Delete Appointment',
  props<{ appointmentId: string }>()
);
