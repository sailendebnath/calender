import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Appointment } from '../models/appointment.model';

@Component({
  selector: 'app-appointment-detail',
  templateUrl: './appointment-detail.component.html',
  styleUrls: ['./appointment-detail.component.scss']
})
export class AppointmentDetailComponent {
  appointment: Appointment;

  constructor(
    public dialogRef: MatDialogRef<AppointmentDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { appointment: Appointment }
  ) {
    this.appointment = { ...data.appointment }; 
  }

  onSave(): void {
    this.dialogRef.close(this.appointment); 
  }

  onCancel(): void {
    this.dialogRef.close(null); 
  }
}
