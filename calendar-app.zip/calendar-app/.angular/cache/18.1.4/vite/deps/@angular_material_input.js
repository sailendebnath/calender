import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-D7GU7DQT.js";
import "./chunk-GCDOC6FO.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-DOSUBFFG.js";
import "./chunk-APVSWG7Z.js";
import "./chunk-CBN253EI.js";
import "./chunk-DN34CHOM.js";
import "./chunk-YGWFGMDE.js";
import "./chunk-JZSODJ3T.js";
import "./chunk-I74C7OVX.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
