import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-LMJML5OV.js";
import "./chunk-M2IMWJAE.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-MSCMNFXZ.js";
import "./chunk-SCKKU7VE.js";
import "./chunk-BJENMSMM.js";
import "./chunk-5N77VNM2.js";
import "./chunk-QB64OUEW.js";
import "./chunk-KGCSKLGS.js";
import "./chunk-Q5BPYVZH.js";
import "./chunk-NQ4HTGF6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
