import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CalendarService } from '../shared/calendar.service';
import { debounceTime } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { NavigationComponent } from '../../navigation.component';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';


@Component({
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    NavigationComponent,
    NgxMaterialTimepickerModule
  ],
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html',
  styleUrls: ['./appointment-form.component.css']
})
export class AppointmentFormComponent {
  appointmentForm: FormGroup;

  constructor(private fb: FormBuilder, private calendarService: CalendarService, private router: Router) {
    this.appointmentForm = this.fb.group({
      title: ['', Validators.required],
      description: [''],
      date: ['', Validators.required],
      time: ['', Validators.required],
      color: ['#ffffff', Validators.required],
      location: [''],
      notes: [''],
      reminders: [[]]
    });

    this.appointmentForm.valueChanges.pipe(
      debounceTime(300)
    ).subscribe(value => {
      console.log('Form changes:', value);
    });
  }

  onSubmit() {
    if (this.appointmentForm.valid) {
      this.calendarService.addAppointment(this.appointmentForm.value);
      console.log('Appointment added:', this.appointmentForm.value);
      this.router.navigate(['/calendar']); 
    }
  }
}
