import { Component, OnInit } from '@angular/core';
import { CalendarService } from '../shared/calendar.service';
import { Appointment } from '../shared/appointment.model';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { Router } from '@angular/router';
import { NavigationComponent } from '../../navigation.component';


@Component({
  standalone: true,
  imports: [CommonModule, MatIconModule, DragDropModule, NavigationComponent],
  selector: 'app-calendar-view',
  templateUrl: './calendar-view.component.html',
  styleUrls: ['./calendar-view.component.css']
})
export class CalendarViewComponent implements OnInit {
  appointments: Appointment[] = [];

  constructor(private calendarService: CalendarService, private router: Router) {}

  ngOnInit() {
    this.appointments = this.calendarService.getAppointments();
  }

  deleteAppointment(appointment: Appointment) {
    this.calendarService.deleteAppointment(appointment);
    this.appointments = this.calendarService.getAppointments();
  }

  drop(event: CdkDragDrop<Appointment[]>) {
    moveItemInArray(this.appointments, event.previousIndex, event.currentIndex);
    // Update the appointments in the service if necessary
  }

  navigateToAddAppointment() {
    this.router.navigate(['/add-appointment']);
  }
}
