import { Injectable } from '@angular/core';
import { Appointment } from './appointment.model';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  private appointments: Appointment[] = [
    {
      title: 'Meeting with Bob',
      description: 'Discuss project updates.',
      date: new Date(),
      time: '10:00 AM',
      color: '#ff4081'
    }
  ];

  getAppointments(): Appointment[] {
    return this.appointments;
  }

  addAppointment(appointment: Appointment) {
    this.appointments.push(appointment);
  }

  deleteAppointment(appointment: Appointment) {
    this.appointments = this.appointments.filter(a => a !== appointment);
  }
}
