export interface Appointment {
    title: string;
    description: string;
    date: Date;
    time: string;
    color: string;
    location?: string;
    notes?: string;
    reminders?: string[];
  }
  