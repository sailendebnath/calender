import { Routes } from '@angular/router';
import { CalendarViewComponent } from './calendar/calendar-view/calendar-view.component';
import { AppointmentFormComponent } from './calendar/appointment-form/appointment-form.component';

export const routes: Routes = [
  { path: 'calendar', component: CalendarViewComponent },
  { path: 'add-appointment', component: AppointmentFormComponent },
  { path: '', redirectTo: '/calendar', pathMatch: 'full' }
];
